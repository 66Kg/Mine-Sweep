package Miner.model;

public enum GameLevel {
Easy,
Normal,
Hard,
Custom,
}
