package Miner.model;

public enum CellState {
	Normal,//0
	Signed,//15
	Question,//9
	Pressed,//14
	Opened,//0+14=14
}
