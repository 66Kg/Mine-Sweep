package Miner.model;

public enum CellType {
Blank,//14
Mine,//12
Bomb,//10
Error,//11
Number,//
}
