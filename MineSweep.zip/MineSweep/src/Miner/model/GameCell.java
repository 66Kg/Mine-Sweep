package Miner.model;

import java.awt.Graphics;
import java.awt.Image;

import Miner.util.Common;
import Miner.util.GameConfig;

public class GameCell {
	private CellState state;
	private CellType type;
	private int mineCount;
	private static Image[]imgs;

	static{
		imgs=new Image[16];
		Common.loadImages(imgs, "imgs/pic");
	}//��̬��ʼ����.ϵͳ����

	private int row;
	private int column;
	public GameCell(int row, int column) {
		this.row = row;
		this.column = column;
		this.state=CellState.Opened;
		this.type=CellType.Blank;
		this.mineCount=0;
	}//ʹ���ֶ�����
	//���Ƶ�Ԫ��
	public void draw(Graphics g){
		int x=column*GameConfig.CELL_SIZE+2;
		int y=row*GameConfig.CELL_SIZE+2;
		g.drawImage(getImage(), x, y,GameConfig.CELL_SIZE,GameConfig.CELL_SIZE, null);
	}
//���ȼ�鵥Ԫ��״̬��ͬ��״̬ȡ��ͬ��ͼƬ
	private Image getImage() {
		int[]imgIndexs={0,15,9,14,14,12,10,11,-1,1,2,3,4,5,6,7,8};//�������鱣��ͼƬ����"-1"ͳһ��ʽ��ռλ,һֱȡ����8
		int index=-1;
		if(state!=CellState.Opened)
			index=state.ordinal();
		else 
		 index=state.ordinal()+type.ordinal()+mineCount;//״̬+���͵�ͼƬ
		return imgs[imgIndexs[index]];//ȡͼƬ�ڶ�����������λ��
	}
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	public CellState getState() {
		return state;
	}
	public void setState(CellState state) {
		this.state = state;
	}
	public CellType getType() {
		return type;
	}
	public void setType(CellType type) {
		this.type = type;
	}
	public int getMineCount() {
		return mineCount;
	}
	public void setMineCount(int mineCount) {
		this.mineCount = mineCount;
	}



}
