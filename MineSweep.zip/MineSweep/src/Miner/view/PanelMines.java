package Miner.view;

import java.awt.Graphics;

import javax.print.attribute.standard.Severity;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import Miner.model.GameCell;
import Miner.model.GameServer;

public class PanelMines extends JPanel{
	public PanelMines() {
		initializeComponents();
	}
	@Override
	public void paint(Graphics g){
		super.paint(g);
		GameServer server=new GameServer();
		server.draw(g);
			
	}
	private void initializeComponents() {
		this.setBorder(new BevelBorder(BevelBorder.LOWERED));		
	}

}
