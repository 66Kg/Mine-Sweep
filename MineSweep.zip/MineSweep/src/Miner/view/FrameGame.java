package Miner.view;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import Miner.util.GameConfig;

public class FrameGame extends JFrame{
	public FrameGame() {
		initializeComponents();

	}
	private void initializeComponents() {
		Box v=Box.createVerticalBox();{
		v.add(Box.createVerticalStrut(4));
		Box h=Box.createHorizontalBox();{
		h.add(Box.createHorizontalStrut(4));
		JPanel board=new JPanel();
		board.setLayout(new BorderLayout(1,4));
		board.add(new Paneldata(),BorderLayout .NORTH);
		board.add(new PanelMines());
		h.add(board);
		}
		h.add(Box.createHorizontalStrut(4));
		v.add(h);
		v.add(Box.createHorizontalStrut(4));
		}
		v.setBorder(new BevelBorder(BevelBorder.RAISED));
		this.add(v);
		this.add(new Paneldata(),BorderLayout.NORTH);
		this.add(new PanelMines());
		this.setJMenuBar(createBar());	
		this.setTitle("MineSweep");
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setIconImage(GameConfig.LOGO.getImage());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	private JMenuBar createBar() {
		JMenuBar bar =new JMenuBar();
		//------------��Ϸ�˵���-------------
		JMenu mnGame=new JMenu("��Ϸ(G)");
		mnGame.setMnemonic('G');
		JMenu mnHelp=new JMenu("����(H)");
		mnGame.setMnemonic('H');
		bar.add(mnGame);
		bar.add(mnHelp);
		return bar;
	}

}