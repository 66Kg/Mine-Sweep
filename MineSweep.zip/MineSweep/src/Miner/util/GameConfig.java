package Miner.util;

import javax.swing.ImageIcon;

import Miner.model.GameLevel;

public class GameConfig {
	public static  ImageIcon LOGO=new ImageIcon("imgs/pic3/logo.png");
	public static  int CELL_SIZE=32;
	private static GameLevel level=GameLevel.Easy;
	private static int[][]rowsAndCols;
	private static int[]maxMines={10,40,99};//�͡��С���
	static{
		rowsAndCols=new int[][]{{10,10},{16,16},{16,30}};//��ͬ�Ѷȿͻ��˿��Ĵ�С
	}
	public static int getRows() {
		return rowsAndCols[level.ordinal()][0];//�������ݵȼ������Ĵ�С
		
	}
	public static int getColumns() {
		return rowsAndCols[level.ordinal()][0];
}
	public static int getClientWigth() {//�ͻ��˿���
		return CELL_SIZE*getColumns();
		
	}
	public static int getClientHigh() {
		return CELL_SIZE*getRows()+80;//�ͻ��˸߶�
}
	public static int getMaxMines() {
		return maxMines[level.ordinal()];
	}
}
