package Miner.util;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Common {
	public static void loadImages(Image[] imgs,String path){
		for (int i=0;i<imgs.length;i++){
			String fileName=String.format("%s/%d.bmp", path,i);
			imgs[i]=new ImageIcon(fileName).getImage();
		}
	}
}
