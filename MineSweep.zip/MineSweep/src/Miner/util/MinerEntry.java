package Miner.util;

import Miner.view.FrameGame;

public class MinerEntry {
	public static void main(String[]args){
		FrameGame frame=new FrameGame();
		frame.setVisible(true);
		int w =GameConfig.getClientWigth()+frame.getInsets().left*2;//��߿�ľ���
		int h=GameConfig.getClientHigh()+frame.getInsets().top+frame.getInsets().bottom;//���±߿�ĸ߶�
		frame.setSize(w, h);
		frame.setLocationRelativeTo(null);//���þ���
	}
}